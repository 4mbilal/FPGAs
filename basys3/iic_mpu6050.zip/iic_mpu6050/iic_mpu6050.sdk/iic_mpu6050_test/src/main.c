#include <stdio.h>
#include "xil_types.h"
#include "xil_io.h"
#include "xiic.h"
#include "xparameters.h"
#include "xil_printf.h"
#include "sleep.h"
#include "MPU6050.h"
#include "I2Cdev.h"

void mpu6050_test(){
	int16_t ax, ay, az, gx, gy, gz;

	// MPU6050
	MPU6050(MPU6050_ADDRESS_AD0_LOW);

	// Initialize device
	printf("Initializing I2C devices...\r\n");
	MPU6050_initialize();

	printf("Device ID: %d\r\n", MPU6050_getDeviceID());
	printf("Sampling Rate: %d\r\n", MPU6050_getRate());
	printf("Acc full Scale: %d\r\n", MPU6050_getFullScaleAccelRange());

	//usleep(1000000);

	//Calibrate
	printf("Calibrating...\r\n");
	float ax_offset,ay_offset,az_offset,gx_offset,gy_offset,gz_offset;
	float ax_f,ay_f,az_f,gx_f,gy_f,gz_f;
	ax_offset = 0;
	ay_offset = 0;
	az_offset = 0;
	gx_offset = 0;
	gy_offset = 0;
	gz_offset = 0;

	for(int i=0;i<1000;i++){
		MPU6050_getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
		ax_offset = ax_offset + ax;
		ay_offset = ay_offset + ay;
		az_offset = az_offset + az;
		gx_offset = gx_offset + gx;
		gy_offset = gy_offset + gy;
		gz_offset = gz_offset + gz;
	}
	ax_offset = -16384+ax_offset/1000;
	ay_offset = ay_offset/1000;
	az_offset = az_offset/1000;
	gx_offset = gx_offset/1000;
	gy_offset = gy_offset/1000;
	gz_offset = gz_offset/1000;

	while (true) {
		// Read raw accel/gyro measurements from device
		MPU6050_getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

		// Display tab-separated accel/gyro x/y/z values
		ax_f = ((float)ax-ax_offset)/16384;
		ay_f = ((float)ay-ay_offset)/16384;
		az_f = ((float)az-az_offset)/16384;
		gx_f = ((float)gx-gx_offset)/16384;
		gy_f = ((float)gy-gy_offset)/16384;
		gz_f = ((float)gz-gz_offset)/16384;
		printf("a/g:\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\r\n", ax_f, ay_f, az_f, gx_f, gy_f, gz_f);

		//usleep(50000);
	}
}


int main() {
	I2Cdev_Init();
	//I2Cdev_Scan();

	while(1){
	mpu6050_test();
	usleep(15000000);
	}
    return 0;
}




