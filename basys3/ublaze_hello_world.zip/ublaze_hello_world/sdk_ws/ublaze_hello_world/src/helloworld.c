/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"

/*
int main()
{
    init_platform();

    print("\n\r\n\r\n\r\n\rStarting Basys3 System ......\n\r\n\r\n\r\n\r");

    while(1){
    	print("Hello from Basys3......\n\r");
    }
    cleanup_platform();
    return 0;
}
*/


int* switches         = (int*) 0x40020000; // only 16 bits
int* leds             = (int*) 0x40020008; // only 16 bits
int* push_buttons     = (int*) 0x40000000; // only 4 bits [Down Right Left Up]
int* segment_data     = (int*) 0x40010000; // only 8 bits
int* segment_enable   = (int*) 0x40000008; // only 4 bits
int counter = 0;

const int svn_sg_code [] = {
	0b11000000,   // 0---------- > index 0
	0b11111001,   // 1---------- > index 1
	0b10100100,   // 2---------- > index 2
	0b10110000,   // 3---------- > index 3
	0b10011001,   // 4---------- > index 4
	0b10010010,   // 5---------- > index 5
	0b10000010,   // 6---------- > index 6
	0b11111000,   // 7---------- > index 7
	0b10000000,   // 8---------- > index 8
	0b10010000,   // 9---------- > index 9
};

void delay(int n) {
	volatile int x = 0;

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			x++;
		}
	}
}

void display( ) {
	int count_tmp = counter;
	int first_digit = count_tmp%10;
	count_tmp =  count_tmp/10;

	int second_digit = count_tmp%10;
	count_tmp =  count_tmp/10;

	int third_digit = count_tmp%10;
	count_tmp =  count_tmp/10;

	int forth_digit = count_tmp%10;

	*segment_data = svn_sg_code[first_digit];
	*segment_enable = 0b1110;
	delay(100);
	*segment_data = svn_sg_code[second_digit];
	*segment_enable = 0b1101;
	delay(100);
	*segment_data = svn_sg_code[third_digit];
	*segment_enable = 0b1011;
	delay(100);
	*segment_data = svn_sg_code[forth_digit];
	*segment_enable = 0b0111;
	delay(100);
}



int main()
{
    init_platform();

    print("Hello Counter\n\r");






    int  up;
    int down;

    for (;;) {
    	*leds = *switches;

    	if (*push_buttons & 0b0010) { // initialization
    		counter = *switches;
    	}
    	if (*push_buttons & 0b0001) { // up
    		up   = 1;
    		down = 0;
    		for (int i = 0; i < 50; i++) {
    			display();
    		}
    	}
    	if (*push_buttons & 0b1000) { // down
    		up   = 0;
    		for (int i = 0; i < 50; i++) {
    			display();
    		}
    		down = 1;
    	}

    	if (up == 1) {
    		counter++;
    		if (counter > 9999)
    			counter = 0;
    		up = 0;
    	}

    	if (down == 1) {
    		counter--;
    		if (counter < 0)
    			counter = 9999;
    		down = 0;
    	}

    	display();

    }



    cleanup_platform();
    return 0;
}
