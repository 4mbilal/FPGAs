/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xbasic_types.h"


void delay_msec(int n);
void delay_usec(int n);
void led_counter();
void seven_segment_display();
void interface_example();

int main()
{
    init_platform();

    print("\n\r\n\r\n\r\n\rStarting Basys3 System ......\n\r\n\r\n\r\n\r");

    //led_counter();
    interface_example();



    while(1){
    	print("Hello from Basys3......\n\r");
    }
    cleanup_platform();
    return 0;
}



int* switches         = (int*) 0x40020000; // only 16 bits
int* leds             = (int*) 0x40010008; // only 16 bits
int* push_buttons     = (int*) 0x40000000; // only 4 bits [Down Right Left Up]
int* segment_data     = (int*) 0x40010000; // only 8 bits
int* segment_enable   = (int*) 0x40000008; // only 4 bits
int counter = 0;



void led_counter(){
	Xuint16 counter = 0;

	while(1){
		*leds = counter;
		counter = counter + 1;
		delay_msec(1000);
	}


}

void delay_msec(int n) {
	volatile int x = 0;
	for (int k = 0; k < n; k++) {
		for (int j = 0; j < 6000; j++) {
			x++;
		}
	}
}

void delay_usec(int n) {
	volatile int x = 0;
	for (int k = 0; k < n; k++) {
		for (int j = 0; j < 6; j++) {
			x++;
		}
	}
}

const int svn_sg_code [] = {
	0b11000000,   // 0---------- > index 0
	0b11111001,   // 1---------- > index 1
	0b10100100,   // 2---------- > index 2
	0b10110000,   // 3---------- > index 3
	0b10011001,   // 4---------- > index 4
	0b10010010,   // 5---------- > index 5
	0b10000010,   // 6---------- > index 6
	0b11111000,   // 7---------- > index 7
	0b10000000,   // 8---------- > index 8
	0b10010000,   // 9---------- > index 9
};

void seven_segment_display(int number){
	/*this function should be called in a tight running loop to ensure proper display
	250 microsecond delay in-between seems to be reasonable sharp for display without flicker. 100 us or lower seems to
	give a slight blur*/

	int delay_us = 250;

	int first_digit = number%10;
	number =  number/10;

	int second_digit = number%10;
	number =  number/10;

	int third_digit = number%10;
	number =  number/10;

	int forth_digit = number%10;

	*segment_data = svn_sg_code[first_digit];
	*segment_enable = 0b1110;
	delay_usec(delay_us);
	*segment_data = svn_sg_code[second_digit];
	*segment_enable = 0b1101;
	delay_usec(delay_us);
	*segment_data = svn_sg_code[third_digit];
	*segment_enable = 0b1011;
	delay_usec(delay_us);
	*segment_data = svn_sg_code[forth_digit];
	*segment_enable = 0b0111;
	delay_usec(delay_us);
}

void interface_example(){
	int number = 0;
	Xuint16 cnt_1 = 0;
	Xuint16 push_buttons_value = 0;

	while(1){
		*leds = *switches;		//SW to LED loopback
		push_buttons_value = *push_buttons;
		seven_segment_display(number);

		cnt_1 = cnt_1 + 1;
		if(cnt_1>10){
			cnt_1 = 0;
			if (push_buttons_value & 0b0001)
				number = number + 1;
			if (push_buttons_value & 0b1000)
				number = number - 1;
			if(number>9999)
				number = 0;
			if(number<0)
				number = 9999;
		}
	}
}
